function openModal() {
    document.getElementById('donationModal').style.display = "block";
}

function closeModal() {
    document.getElementById('donationModal').style.display = "none";
}

function handleSubmit(event) {
    event.preventDefault();
    var amount = document.getElementById('amount').value;
    if (amount <= 0) {
        Swal.fire('Error', 'Por favor, introduce una cantidad válida para donar.', 'error');
        return false;
    }

    // Aquí puedes enviar el formulario a PayPal (puedes usar AJAX si lo prefieres)
    // Por ahora, solo mostramos el mensaje de agradecimiento
    Swal.fire({
        title: '¡Gracias por tu donación!',
        text: 'Tu apoyo es muy importante para nosotros.',
        icon: 'success',
        confirmButtonText: 'Aceptar'
    }).then(() => {
        // Si deseas redirigir al usuario a PayPal después del agradecimiento, descomenta la siguiente línea:
        // document.getElementById('donationForm').submit();
    });

    closeModal();
    return false; // Evitar que se envíe el formulario por defecto
}
