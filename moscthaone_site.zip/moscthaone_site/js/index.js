document.getElementById('conocenosBtn').addEventListener('click', function(event) {
    event.preventDefault(); // Evita el comportamiento por defecto

    const transition = document.createElement('div');
    transition.classList.add('transition');
    document.body.appendChild(transition);

    // Inicia la animación
    setTimeout(() => {
        transition.classList.add('active');
    }, 10); // Tiempo para asegurar que la clase se agregue después de que se haya agregado el elemento

    // Redirige después de la animación
    setTimeout(() => {
        window.location.href = 'home.html';
    }, 500); // El mismo tiempo que la transición
});
